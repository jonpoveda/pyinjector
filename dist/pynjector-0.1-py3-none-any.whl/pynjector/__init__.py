# -*- coding: utf-8 -*-
""" Flint dependency injector from Pipenv for Python """

__version__ = '0.1'
